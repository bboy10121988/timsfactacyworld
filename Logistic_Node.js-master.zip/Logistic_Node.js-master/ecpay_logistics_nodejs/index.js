/**
 * Created by ecpay on 2017/6/29.
 */
'use strict';

module.exports = require('./lib/ecpay_logistics.js');