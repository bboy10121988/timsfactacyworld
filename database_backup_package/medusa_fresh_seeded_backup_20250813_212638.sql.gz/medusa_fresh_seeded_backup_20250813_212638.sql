--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18 (Homebrew)
-- Dumped by pg_dump version 14.18 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: affiliate_commission; Type: TABLE; Schema: public; Owner: raychou
--

CREATE TABLE public.affiliate_commission (
    id character varying NOT NULL,
    order_id character varying NOT NULL,
    partner_id character varying NOT NULL,
    order_date date NOT NULL,
    order_amount numeric(12,2) NOT NULL,
    commission_rate numeric(5,4) NOT NULL,
    commission_amount numeric(12,2) NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    settlement_date date,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT affiliate_commission_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'processing'::character varying, 'paid'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.affiliate_commission OWNER TO raychou;

--
-- Name: affiliate_partner; Type: TABLE; Schema: public; Owner: raychou
--

CREATE TABLE public.affiliate_partner (
    id character varying NOT NULL,
    name character varying NOT NULL,
    partner_code character varying NOT NULL,
    email character varying NOT NULL,
    phone character varying,
    commission_rate numeric(5,4) DEFAULT 0.1000 NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    rejection_reason text,
    approved_by character varying,
    approved_at timestamp with time zone,
    metadata jsonb,
    total_orders integer DEFAULT 0 NOT NULL,
    total_commission_earned numeric(12,2) DEFAULT 0 NOT NULL,
    total_commission_paid numeric(12,2) DEFAULT 0 NOT NULL,
    last_order_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT affiliate_partner_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'suspended'::character varying])::text[])))
);


ALTER TABLE public.affiliate_partner OWNER TO raychou;

--
-- Data for Name: affiliate_commission; Type: TABLE DATA; Schema: public; Owner: raychou
--

COPY public.affiliate_commission (id, order_id, partner_id, order_date, order_amount, commission_rate, commission_amount, status, settlement_date, metadata, created_at, updated_at) FROM stdin;
aff_comm_013_01	order_20250107_013	aff_partner_013	2025-01-07	8500.00	0.0750	637.50	approved	\N	{"product_name": "Tim's 時尚胸罩套裝", "customer_type": "new"}	2025-01-07 00:00:00+08	2025-01-08 00:00:00+08
aff_comm_013_02	order_20250109_013	aff_partner_013	2025-01-09	12000.00	0.0750	900.00	paid	2025-01-10	{"product_name": "Tim's 限量款胸罩", "customer_type": "returning"}	2025-01-09 00:00:00+08	2025-01-10 00:00:00+08
aff_comm_014_01	order_20250108_014	aff_partner_014	2025-01-08	15600.00	0.0900	1404.00	processing	\N	{"product_name": "Tim's 網紅推薦組合", "customer_type": "new"}	2025-01-08 00:00:00+08	2025-01-08 00:00:00+08
aff_comm_019_01	order_20250106_019	aff_partner_019	2025-01-06	25000.00	0.1500	3750.00	paid	2025-01-07	{"product_name": "Tim's VIP專屬系列", "customer_type": "vip"}	2025-01-06 00:00:00+08	2025-01-07 00:00:00+08
\.


--
-- Data for Name: affiliate_partner; Type: TABLE DATA; Schema: public; Owner: raychou
--

COPY public.affiliate_partner (id, name, partner_code, email, phone, commission_rate, status, rejection_reason, approved_by, approved_at, metadata, total_orders, total_commission_earned, total_commission_paid, last_order_at, created_at, updated_at) FROM stdin;
aff_partner_010	王小明網路行銷	WANG001	wang@marketing-pro.com	0912-345-678	0.0000	pending	\N	\N	\N	{"company": "個人工作室", "experience": "3年", "speciality": "社群媒體"}	0	0.00	0.00	\N	2025-08-07 10:44:26.041759+08	2025-08-07 10:44:26.041759+08
aff_partner_011	李美華數位廣告	LEE002	li@digital-ads.tw	0923-456-789	0.0000	pending	\N	\N	\N	{"company": "李美華數位廣告有限公司", "experience": "5年", "speciality": "Google廣告"}	0	0.00	0.00	\N	2025-08-08 10:44:26.041759+08	2025-08-08 10:44:26.041759+08
aff_partner_013	張美玲時尚部落格	ZHANG004	zhang@fashion-blog.tw	0945-678-901	0.0750	approved	\N	admin_001	2025-07-30 10:44:26.041759+08	{"company": "美玲時尚部落格", "experience": "4年", "speciality": "時尚美妝"}	0	0.00	0.00	\N	2025-07-25 10:44:26.041759+08	2025-07-30 10:44:26.041759+08
aff_partner_014	林志豪網紅行銷	LIN005	lin@influencer-marketing.com	0956-789-012	0.0900	approved	\N	admin_001	2025-08-04 10:44:26.041759+08	{"company": "志豪網紅行銷有限公司", "experience": "6年", "speciality": "網紅合作"}	0	0.00	0.00	\N	2025-08-02 10:44:26.041759+08	2025-08-04 10:44:26.041759+08
aff_partner_015	黃佳慧生活風格	HUANG006	huang@lifestyle-blog.tw	0967-890-123	0.0650	approved	\N	admin_001	2025-07-20 10:44:26.041759+08	{"company": "佳慧生活風格工作室", "experience": "3年", "speciality": "生活用品推薦"}	0	0.00	0.00	\N	2025-07-15 10:44:26.041759+08	2025-07-20 10:44:26.041759+08
aff_partner_016	吳小華	WU007	wu@personal.email	0978-901-234	0.0000	rejected	\N	admin_001	2025-08-06 10:44:26.041759+08	{"company": "個人", "experience": "無", "rejection_reason": "缺乏相關經驗"}	0	0.00	0.00	\N	2025-08-04 10:44:26.041759+08	2025-08-06 10:44:26.041759+08
aff_partner_017	劉大明雜貨店	LIU008	liu@grocery-store.com	0989-012-345	0.0000	rejected	\N	admin_001	2025-08-08 10:44:26.041759+08	{"company": "劉大明雜貨店", "experience": "1年", "rejection_reason": "業務範圍不符"}	0	0.00	0.00	\N	2025-08-05 10:44:26.041759+08	2025-08-08 10:44:26.041759+08
aff_partner_018	趙小花購物達人	ZHAO009	zhao@shopping-expert.tw	0990-123-456	0.0500	suspended	\N	admin_001	2025-07-10 10:44:26.041759+08	{"company": "小花購物達人工作室", "experience": "2年", "suspension_reason": "違規推廣"}	0	0.00	0.00	\N	2025-06-10 10:44:26.041759+08	2025-08-07 10:44:26.041759+08
aff_partner_019	VIP行銷顧問公司	VIP001	contact@vip-marketing.com	02-8765-4321	0.1500	approved	\N	admin_001	2025-05-11 10:44:26.041759+08	{"tier": "diamond", "company": "VIP行銷顧問有限公司", "experience": "10年", "speciality": "企業合作"}	0	0.00	0.00	\N	2025-05-01 10:44:26.041759+08	2025-05-11 10:44:26.041759+08
test-id-123	直接SQL測試夥伴	SQL123TEST	sql@example.com	0912345678	0.0800	approved	\N	\N	\N	\N	0	0.00	0.00	\N	2025-08-11 19:35:42.523616+08	2025-08-11 19:35:42.523616+08
test_direct_123	Direct Test	TESTCODE123	direct@test.com	0999888777	0.0800	pending	\N	\N	\N	\N	0	0.00	0.00	\N	2025-08-11 20:27:18.202198+08	2025-08-11 20:27:18.202198+08
\.


--
-- Name: affiliate_commission affiliate_commission_pkey; Type: CONSTRAINT; Schema: public; Owner: raychou
--

ALTER TABLE ONLY public.affiliate_commission
    ADD CONSTRAINT affiliate_commission_pkey PRIMARY KEY (id);


--
-- Name: affiliate_partner affiliate_partner_email_key; Type: CONSTRAINT; Schema: public; Owner: raychou
--

ALTER TABLE ONLY public.affiliate_partner
    ADD CONSTRAINT affiliate_partner_email_key UNIQUE (email);


--
-- Name: affiliate_partner affiliate_partner_partner_code_key; Type: CONSTRAINT; Schema: public; Owner: raychou
--

ALTER TABLE ONLY public.affiliate_partner
    ADD CONSTRAINT affiliate_partner_partner_code_key UNIQUE (partner_code);


--
-- Name: affiliate_partner affiliate_partner_pkey; Type: CONSTRAINT; Schema: public; Owner: raychou
--

ALTER TABLE ONLY public.affiliate_partner
    ADD CONSTRAINT affiliate_partner_pkey PRIMARY KEY (id);


--
-- Name: IDX_affiliate_commission_date; Type: INDEX; Schema: public; Owner: raychou
--

CREATE INDEX "IDX_affiliate_commission_date" ON public.affiliate_commission USING btree (order_date);


--
-- Name: IDX_affiliate_commission_order; Type: INDEX; Schema: public; Owner: raychou
--

CREATE INDEX "IDX_affiliate_commission_order" ON public.affiliate_commission USING btree (order_id);


--
-- Name: IDX_affiliate_commission_partner; Type: INDEX; Schema: public; Owner: raychou
--

CREATE INDEX "IDX_affiliate_commission_partner" ON public.affiliate_commission USING btree (partner_id);


--
-- Name: IDX_affiliate_commission_status; Type: INDEX; Schema: public; Owner: raychou
--

CREATE INDEX "IDX_affiliate_commission_status" ON public.affiliate_commission USING btree (status);


--
-- Name: IDX_affiliate_partner_code; Type: INDEX; Schema: public; Owner: raychou
--

CREATE INDEX "IDX_affiliate_partner_code" ON public.affiliate_partner USING btree (partner_code);


--
-- Name: IDX_affiliate_partner_email; Type: INDEX; Schema: public; Owner: raychou
--

CREATE INDEX "IDX_affiliate_partner_email" ON public.affiliate_partner USING btree (email);


--
-- Name: IDX_affiliate_partner_status; Type: INDEX; Schema: public; Owner: raychou
--

CREATE INDEX "IDX_affiliate_partner_status" ON public.affiliate_partner USING btree (status);


--
-- Name: affiliate_commission FK_affiliate_commission_partner; Type: FK CONSTRAINT; Schema: public; Owner: raychou
--

ALTER TABLE ONLY public.affiliate_commission
    ADD CONSTRAINT "FK_affiliate_commission_partner" FOREIGN KEY (partner_id) REFERENCES public.affiliate_partner(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

